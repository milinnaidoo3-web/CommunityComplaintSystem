﻿using CommunityConnect.Models;

namespace CommunityConnect.Services
{
    public class ComplaintService
    {
        private readonly List<Complaint> _complaints = new();
        private int _nextId = 1;

        public List<Complaint> GetAll() => _complaints;

        public Complaint? GetById(int id) => _complaints.FirstOrDefault(c => c.Id == id);

        public void Add(Complaint complaint)
        {
            complaint.Id = _nextId++;
            _complaints.Add(complaint);
        }

        public void Update(Complaint updated)
        {
            var existing = GetById(updated.Id);
            if (existing != null)
            {
                existing.Name = updated.Name;
                existing.PhoneNumber = updated.PhoneNumber;
                existing.Type = updated.Type;
                existing.Description = updated.Description;
                existing.ImagePath = updated.ImagePath;
                existing.MapLocation = updated.MapLocation;
                existing.Status = updated.Status;
            }
        }

        public void UpdateStatus(int id, ComplaintStatus status)
        {
            var complaint = GetById(id);
            if (complaint != null)
                complaint.Status = status;
        }

        public void Delete(int id)
        {
            var complaint = GetById(id);
            if (complaint != null)
                _complaints.Remove(complaint);
        }
    }
}
