using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CommunityConnect.Models;
using CommunityConnect.Services;

namespace CommunityConnect.Pages
{
    public class ViewModel : PageModel
    {
        private readonly ComplaintService _service;
        public List<Complaint> Complaints { get; set; } = new();

        public ViewModel(ComplaintService service) => _service = service;

        public void OnGet() => Complaints = _service.GetAll();

        public IActionResult OnPostDelete(int id)
        {
            _service.Delete(id);
            return RedirectToPage();
        }
    }
}
