using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CommunityConnect.Models;
using CommunityConnect.Services;

namespace CommunityConnect.Pages
{
    public class SubmitModel : PageModel
    {
        private readonly ComplaintService _service;
        private readonly IWebHostEnvironment _env;

        [BindProperty]
        public Complaint Complaint { get; set; } = new();

        [BindProperty]
        public IFormFile? ImageUpload { get; set; }

        public SubmitModel(ComplaintService service, IWebHostEnvironment env)
        {
            _service = service;
            _env = env;
        }

        public void OnGet()
        {
            Complaint.MapLocation = "https://www.google.com/maps/place/South+Africa";
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
                return Page();

            if (ImageUpload != null)
            {
                var fileName = $"{Guid.NewGuid()}{Path.GetExtension(ImageUpload.FileName)}";
                var filePath = Path.Combine(_env.WebRootPath, "uploads", fileName);
                Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);
                using var stream = System.IO.File.Create(filePath);
                ImageUpload.CopyTo(stream);
                Complaint.ImagePath = $"/uploads/{fileName}";
            }

            _service.Add(Complaint);
            return RedirectToPage("/View");
        }
    }
}
