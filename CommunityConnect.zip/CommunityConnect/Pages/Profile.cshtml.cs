using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CommunityConnect.Pages
{
    public class ProfileModel : PageModel
    {
        // Simulated user data (replace with your user service as needed)
        [BindProperty]
        public string Name { get; set; } = "Demo User";
        [BindProperty]
        public string Email { get; set; } = "demo.user@example.com";
        [BindProperty]
        public string Phone { get; set; } = "(555) 123-4567";
        [BindProperty]
        public string Address { get; set; } = "123 Main St, City, State 12345";

        // For password change
        [BindProperty]
        public string NewPassword { get; set; }
        [BindProperty]
        public string ConfirmPassword { get; set; }

        public string StatusMessage { get; set; }

        public void OnGet() { }

        public IActionResult OnPostEdit()
        {
            // Simulate update
            StatusMessage = "Profile updated successfully.";
            return Page();
        }

        public IActionResult OnPostChangePassword()
        {
            if (NewPassword != ConfirmPassword)
            {
                StatusMessage = "Passwords do not match.";
                return Page();
            }
            // Simulate password change
            StatusMessage = "Password changed successfully.";
            return Page();
        }
    }
}
