using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CommunityConnect.Pages
{
    public class HelpModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
