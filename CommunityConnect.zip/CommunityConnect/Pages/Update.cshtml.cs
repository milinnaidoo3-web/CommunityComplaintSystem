using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CommunityConnect.Models;
using CommunityConnect.Services;

namespace CommunityConnect.Pages
{
    public class UpdateModel : PageModel
    {
        private readonly ComplaintService _service;

        [BindProperty]
        public int Id { get; set; }

        [BindProperty]
        public ComplaintStatus Status { get; set; }

        public UpdateModel(ComplaintService service) => _service = service;

        public IActionResult OnGet(int id)
        {
            var complaint = _service.GetById(id);
            if (complaint == null) return RedirectToPage("/View");
            Id = complaint.Id;
            Status = complaint.Status;
            return Page();
        }

        public IActionResult OnPost()
        {
            _service.UpdateStatus(Id, Status);
            return RedirectToPage("/View");
        }
    }
}
