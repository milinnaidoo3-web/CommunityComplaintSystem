using Microsoft.AspNetCore.Mvc.RazorPages;

public class AboutModel : PageModel
{
    public void OnGet() { }
}
