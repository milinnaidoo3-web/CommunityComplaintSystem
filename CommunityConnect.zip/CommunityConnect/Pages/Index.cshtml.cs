using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CommunityConnect.Services;
using CommunityConnect.Models;
using System.Text.Json;

namespace CommunityConnect.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ComplaintService _service;
        public int NotStarted { get; set; }
        public int InProgress { get; set; }
        public int Resolved { get; set; }
        public int Total { get; set; }
        public List<Complaint> RecentComplaints { get; set; } = new();
        public List<string> TypeLabels { get; set; } = new();
        public List<int> TypeCounts { get; set; } = new();

        public IndexModel(ComplaintService service) => _service = service;

        public void OnGet()
        {
            var complaints = _service.GetAll();
            NotStarted = complaints.Count(c => c.Status == ComplaintStatus.NotStarted);
            InProgress = complaints.Count(c => c.Status == ComplaintStatus.InProgress);
            Resolved = complaints.Count(c => c.Status == ComplaintStatus.Resolved);
            Total = complaints.Count;
            RecentComplaints = complaints.OrderByDescending(c => c.CreatedAt).Take(5).ToList();

            // Complaints by Type
            TypeLabels = Enum.GetNames(typeof(ComplaintType)).ToList();
            TypeCounts = TypeLabels.Select(label =>
                complaints.Count(c => c.Type.ToString() == label)).ToList();
        }
    }
}
