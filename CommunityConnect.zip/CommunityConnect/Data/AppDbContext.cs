using Microsoft.EntityFrameworkCore;
using CommunityConnect.Models;

namespace CommunityConnect.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Complaint> Complaints { get; set; }
    }
}