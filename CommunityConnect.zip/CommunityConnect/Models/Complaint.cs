﻿using System.ComponentModel.DataAnnotations;

namespace CommunityConnect.Models
{
    public enum ComplaintStatus { NotStarted, InProgress, Resolved }
    public enum ComplaintType { Water, Electric, Infrastructure, Road, Other }

    public class Complaint
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } = "";

        [Required]
        [Phone]
        public string PhoneNumber { get; set; } = "";

        [Required]
        public ComplaintType Type { get; set; }

        [Required]
        public string Description { get; set; } = "";

        public string? ImagePath { get; set; }

        [Required]
        [Url]
        public string MapLocation { get; set; } = "";

        public ComplaintStatus Status { get; set; } = ComplaintStatus.NotStarted;

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
